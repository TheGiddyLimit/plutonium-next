# Auto-Loaded Homebrew

This directory contains an index (`index.json`) of homebrew files which will be loaded and displayed in the appropriate importer lists.

To use, simply place a homebrew file in this directory, add its name to the index.

For example, add `"My Homebrew.json"` to the "toImport" array in `index.json`, and have a valid JSON homebrew file with the name `My Homebrew.json` in this directory.

---

This feature can be disabled by enabling the "Avoid Loading Local Homebrew" Import Config option.
