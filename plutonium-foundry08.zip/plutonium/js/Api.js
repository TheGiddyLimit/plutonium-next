import {SharedConsts} from "../shared/SharedConsts.js";
import {UtilApplications} from "./UtilApplications.js";
import {ImportListCreature} from "./ImportListCreature.js";

class Api {
	static init () {
		game.apis = game.apis || {};
		game.apis[SharedConsts.MODULE_NAME_FAKE] = {
			importer: {
				creature: {
					pImportEntry: ImportListCreature.api_pImportEntry.bind(ImportListCreature),
				},
			},
			util: {
				apps: {
					doAutoResize: UtilApplications.autoResizeApplication.bind(UtilApplications),
				},
			},
		};
	}
}

export {Api};
