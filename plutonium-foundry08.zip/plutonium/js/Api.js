import {SharedConsts} from "../shared/SharedConsts.js";
import {UtilApplications} from "./UtilApplications.js";
import {ImportListCreature} from "./ImportListCreature.js";
import {NamedTokenCreator} from "./NamedTokenCreator.js";

class Api {
	static init () {
		const api = {
			importer: {
				creature: {
					pImportEntry: ImportListCreature.api_pImportEntry.bind(ImportListCreature),
				},
			},
			token: {
				pCreateToken: NamedTokenCreator.pCreateToken.bind(NamedTokenCreator),
			},
			util: {
				apps: {
					doAutoResize: UtilApplications.autoResizeApplication.bind(UtilApplications),
					$getAppElement: UtilApplications.$getAppElement.bind(UtilApplications),
				},
			},
		};

		game.modules.get(SharedConsts.MODULE_NAME).api = api;

		const cpy = MiscUtil.copy(game.modules.get(SharedConsts.MODULE_NAME));
		cpy.id = SharedConsts.MODULE_NAME_FAKE;
		cpy.api = api;
		game.modules.set(SharedConsts.MODULE_NAME_FAKE, cpy);
	}
}

export {Api};
