class DataConverterFeature {
	static async pPreloadSideData () {
		this._SIDE_DATA = await this._getPreloadSideData();
	}

	static async _getPreloadSideData () { throw new Error("Unimplemented!"); }
}
DataConverterFeature._SIDE_DATA = null;

export {DataConverterFeature};
