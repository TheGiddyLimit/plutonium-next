import {UtilApplications} from "./UtilApplications.js";
import {Config} from "./Config.js";
import {DataConverter} from "./DataConverter.js";
import {Vetools} from "./Vetools.js";

class DataConverterLanguage {
	/**
	 * @param ent
	 * @param [opts] Options object.
	 * @param [opts.isAddPermission]
	 */
	static async pGetLanguageJournal (ent, opts) {
		opts = opts || {};

		const content = await DataConverter.pGetWithDescriptionPlugins(() => `<div>${Renderer.language.getRenderedString(ent, {isSkipNameRow: true})}</div>`);

		const fluff = await Renderer.utils.pGetFluff({
			entity: ent,
			fluffUrl: `data/fluff-languages.json`,
			fluffProp: "languageFluff",
		});

		const img = fluff?.images?.length
			? await Vetools.pOptionallySaveImageToServerAndGetUrl(Renderer.utils.getMediaUrl(fluff.images[0], "href", "img"))
			: null;

		const out = {
			name: UtilApplications.getCleanEntityName(DataConverter.getNameWithSourcePart(ent)),
			permission: {default: 0},
			entryTime: Date.now(),
			content,
			img,
		};

		if (opts.isAddPermission) out.permission = {default: Config.get("importLanguage", "permissions")};

		return out;
	}
}

export {DataConverterLanguage};
