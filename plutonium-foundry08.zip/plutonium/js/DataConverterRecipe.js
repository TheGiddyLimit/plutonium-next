import {UtilApplications} from "./UtilApplications.js";
import {Config} from "./Config.js";
import {DataConverter} from "./DataConverter.js";

class DataConverterRecipe {
	/**
	 * @param recipe
	 * @param [opts] Options object.
	 * @param [opts.isAddPermission]
	 */
	static async pGetRecipeJournal (recipe, opts) {
		opts = opts || {};

		const content = DataConverter.getWithDescriptionPlugins(() => Renderer.recipe.getBodyHtml(recipe));

		const fluff = await Renderer.utils.pGetFluff({
			entity: recipe,
			fluffUrl: `data/fluff-recipes.json`,
			fluffProp: "recipeFluff",
		});

		const img = fluff?.images?.length ? Renderer.utils.getMediaUrl(fluff.images[0], "href", "img") : null;

		const out = {
			name: UtilApplications.getCleanEntityName(DataConverter.getNameWithSourcePart(recipe)),
			permission: {default: 0},
			entryTime: Date.now(),
			content,
			img,
		};

		if (opts.isAddPermission) out.permission = {default: Config.get("importRecipe", "permissions")};

		return out;
	}
}

export {DataConverterRecipe};
