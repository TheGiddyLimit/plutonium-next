import {UtilApplications} from "./UtilApplications.js";
import {SharedConsts} from "../shared/SharedConsts.js";
import {Config} from "./Config.js";
import {DataConverter} from "./DataConverter.js";
import {Vetools} from "./Vetools.js";
import {UtilActiveEffects} from "./UtilActiveEffects.js";

class DataConverterReward {
	/**
	 * @param reward
	 * @param [opts] Options object.
	 * @param [opts.isAddPermission]
	 * @param [opts.isActorItem]
	 * @param [opts.actor]
	 */
	static async pGetRewardItem (reward, opts) {
		opts = opts || {};
		if (opts.actor) opts.isActorItem = true;

		const content = Config.get("importReward", "isImportDescription") ? DataConverter.getWithDescriptionPlugins(() => `<div>${Renderer.get().setFirstSection(true).render({entries: reward.entries}, 2)}</div>`) : "";

		const additionalData = await this._pGetAdditionalData(reward);

		const out = {
			name: UtilApplications.getCleanEntityName(DataConverter.getNameWithSourcePart(reward, {isActorItem: opts.isActorItem})),
			data: {
				source: DataConverter.getSourceWithPagePart(reward),
				description: {
					value: content,
					chat: "",
					unidentified: "",
				},

				activation: {type: "", cost: 0, condition: ""},
				duration: {value: 0, units: ""},
				target: {value: 0, units: "", type: ""},
				range: {value: 0, long: 0, units: null},
				uses: {value: 0, max: 0, per: ""},
				ability: "",
				actionType: "",
				attackBonus: 0,
				chatFlavor: "",
				critical: null,
				damage: {parts: [], versatile: ""},
				formula: "",
				save: {ability: "", dc: null},
				requirements: "",
				recharge: {value: 0, charged: true},

				...additionalData,
			},
			permission: {default: 0},
			type: "feat",
			img: `modules/${SharedConsts.MODULE_NAME}/media/icon/mighty-force.svg`,
			flags: this._getRewardFlags(reward, opts),
			effects: [],
		};

		if (opts.isAddPermission) out.permission = {default: Config.get("importReward", "permissions")};

		return out;
	}

	static async pMutActorUpdateReward (actor, actorUpdate, optFeature, dataBuilderOpts) {
		const sideData = await this.pGetSideData(optFeature);
		DataConverter.mutActorUpdate(actor, actorUpdate, optFeature, {sideData});
	}

	static _getRewardFlags (reward, opts) {
		opts = opts || {};

		const out = {
			[SharedConsts.MODULE_NAME_FAKE]: {
				page: UrlUtil.PG_REWARDS,
				source: reward.source,
				hash: UrlUtil.URL_TO_HASH_BUILDER[UrlUtil.PG_REWARDS](reward),
			},
		};

		if (opts.isAddDataFlags) {
			out[SharedConsts.MODULE_NAME_FAKE].propDroppable = "reward";
			out[SharedConsts.MODULE_NAME_FAKE].filterValues = opts.filterValues;
		}

		return out;
	}

	static async pGetSideData (optFeature) {
		return DataConverter.pGetSideData_(
			optFeature,
			{
				propBrew: "foundryReward",
				fnLoadJson: async () => DataConverterReward._SIDE_DATA || Vetools.pGetRewardSideData(),
				propJson: "reward",
			},
		);
	}

	static async _pGetAdditionalData (reward) {
		return DataConverter.pGetAdditionalData_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"});
	}

	static async pHasRewardSideLoadedEffects (actor, reward) {
		return (await DataConverter.pGetAdditionalEffectsRaw_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"}))?.length > 0;
	}

	static async pGetRewardItemEffects (actor, reward, sheetItem, {additionalData} = {}) {
		const effectsRaw = await DataConverter.pGetAdditionalEffectsRaw_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"});
		return UtilActiveEffects.getExpandedEffects(effectsRaw || [], {actor, sheetItem, parentName: reward.name, additionalData});
	}
}
DataConverterReward._SIDE_DATA = null;

export {DataConverterReward};
