import {UtilApplications} from "./UtilApplications.js";
import {SharedConsts} from "../shared/SharedConsts.js";
import {Config} from "./Config.js";
import {DataConverter} from "./DataConverter.js";
import {Vetools} from "./Vetools.js";
import {UtilActiveEffects} from "./UtilActiveEffects.js";
import {PageFilterClassesFoundry} from "./UtilCharactermancerClass.js";
import {DataConverterFeature} from "./DataConverterFeature.js";

class DataConverterReward extends DataConverterFeature {
	static async pGetDereferencedRewardFeatureItem (feature) {
		const hash = UrlUtil.URL_TO_HASH_BUILDER[UrlUtil.PG_REWARDS](feature);
		return Renderer.hover.pCacheAndGet(UrlUtil.PG_REWARDS, feature.source, hash, {isCopy: true});
	}

	static async pGetInitRewardFeatureLoadeds (feature) {
		const asFeatRef = {reward: `${feature.name}|${feature.source}`};
		await PageFilterClassesFoundry.pInitRewardLoadeds({reward: asFeatRef});
		return asFeatRef;
	}

	/**
	 * @param reward
	 * @param [opts] Options object.
	 * @param [opts.isAddPermission]
	 * @param [opts.isActorItem]
	 * @param [opts.actor]
	 */
	static async pGetRewardItem (reward, opts) {
		opts = opts || {};
		if (opts.actor) opts.isActorItem = true;

		const descriptionValue = this._getGenericDescription(reward, "importReward");

		const additionalData = await this._pGetAdditionalData(reward);

		const img = await this._pGetImagePath(reward, "reward");

		const out = {
			name: UtilApplications.getCleanEntityName(DataConverter.getNameWithSourcePart(reward, {isActorItem: opts.isActorItem})),
			data: {
				source: DataConverter.getSourceWithPagePart(reward),
				description: {
					value: descriptionValue,
					chat: "",
					unidentified: "",
				},

				activation: {type: "", cost: 0, condition: ""},
				duration: {value: 0, units: ""},
				target: {value: 0, units: "", type: ""},
				range: {value: 0, long: 0, units: null},
				uses: {value: 0, max: 0, per: ""},
				ability: "",
				actionType: "",
				attackBonus: 0,
				chatFlavor: "",
				critical: null,
				damage: {parts: [], versatile: ""},
				formula: "",
				save: {ability: "", dc: null},
				requirements: "",
				recharge: {value: 0, charged: true},

				...additionalData,
			},
			permission: {default: 0},
			type: "feat",
			img,
			flags: this._getRewardFlags(reward, opts),
			effects: [],
		};

		if (opts.isAddPermission) out.permission = {default: Config.get("importReward", "permissions")};

		return out;
	}

	static async pMutActorUpdateReward (actor, actorUpdate, optFeature, dataBuilderOpts) {
		const sideData = await this.pGetSideData(optFeature);
		DataConverter.mutActorUpdate(actor, actorUpdate, optFeature, {sideData});
	}

	static _getRewardFlags (reward, opts) {
		opts = opts || {};

		const out = {
			[SharedConsts.MODULE_NAME_FAKE]: {
				page: UrlUtil.PG_REWARDS,
				source: reward.source,
				hash: UrlUtil.URL_TO_HASH_BUILDER[UrlUtil.PG_REWARDS](reward),
			},
		};

		if (opts.isAddDataFlags) {
			out[SharedConsts.MODULE_NAME_FAKE].propDroppable = "reward";
			out[SharedConsts.MODULE_NAME_FAKE].filterValues = opts.filterValues;
		}

		return out;
	}

	static async pGetSideData (optFeature) {
		return DataConverter.pGetSideData_(
			optFeature,
			{
				propBrew: "foundryReward",
				fnLoadJson: async () => this._SIDE_DATA || this._getPreloadSideData(),
				propJson: "reward",
			},
		);
	}

	static async _pGetAdditionalData (reward) {
		return DataConverter.pGetAdditionalData_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"});
	}

	static async pHasRewardSideLoadedEffects (actor, reward) {
		return (await DataConverter.pGetAdditionalEffectsRaw_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"}))?.length > 0;
	}

	static async pGetRewardItemEffects (actor, reward, sheetItem, {additionalData} = {}) {
		const effectsRaw = await DataConverter.pGetAdditionalEffectsRaw_(reward, {propBrew: "foundryReward", fnLoadJson: Vetools.pGetRewardSideData, propJson: "reward"});
		return UtilActiveEffects.getExpandedEffects(effectsRaw || [], {actor, sheetItem, parentName: reward.name, additionalData});
	}

	static async _getPreloadSideData () { return Vetools.pGetRewardSideData(); }
}

export {DataConverterReward};
