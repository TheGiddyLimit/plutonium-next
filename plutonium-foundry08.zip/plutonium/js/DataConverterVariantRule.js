import {UtilApplications} from "./UtilApplications.js";
import {Config} from "./Config.js";
import {DataConverter} from "./DataConverter.js";

class DataConverterVariantRule {
	/**
	 * @param rule
	 * @param [opts] Options object.
	 * @param [opts.isAddPermission]
	 */
	static async pGetVariantRuleJournal (rule, opts) {
		opts = opts || {};

		const cpy = MiscUtil.copy(rule);
		delete cpy.name;
		delete cpy.page;
		delete cpy.source;

		const content = await DataConverter.pGetWithDescriptionPlugins(() => `<div>${Renderer.get().setFirstSection(true).render(cpy)}</div>`);

		const out = {
			name: UtilApplications.getCleanEntityName(DataConverter.getNameWithSourcePart(rule)),
			permission: {default: 0},
			entryTime: Date.now(),
			content,
		};

		if (opts.isAddPermission) out.permission = {default: Config.get("importRule", "permissions")};

		return out;
	}
}

export {DataConverterVariantRule};
