import {ImportListAdventureBook} from "./ImportListAdventureBook.js";
import {Vetools} from "./Vetools.js";
import {DataConverter} from "./DataConverter.js";

class ImportListBook extends ImportListAdventureBook {
	constructor (externalData) {
		super(
			{title: "Import Book"},
			externalData,
			{
				titleSearch: "books",
				defaultFolderPath: ["Books"],
				namespace: "book",
				isFolderOnly: true,
			},
			{
				fnGetIndex: Vetools.pGetBookIndex.bind(Vetools),
				fnGetUrl: Vetools.getBookUrl.bind(Vetools),
				dataProp: "book",
				brewDataProp: "bookData",
				title: "Book",
			},
		);
	}

	_getJournalDatas () {
		return DataConverter.getBookJournals(this._content.data, this._content._contentMetadata, {isAddPermission: true})
	}
}

export {ImportListBook};
