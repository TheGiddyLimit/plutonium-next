import {ActorItemCleaner} from "./ActorItemCleaner.js";
import {ActorSpellPreparedToggler} from "./ActorSpellPreparedToggler.js";
import {ActorPolymorpher} from "./ActorPolymorpher.js";
import {Menu} from "./Menu.js";
import {UtilMigrate} from "./UtilMigrate.js";

class MenuActorTitleTools extends Menu {
	// region External
	static init () {
		Hooks.on("renderActorSheet", (app, $html, data) => {
			const menu = new MenuActorTitleTools();
			menu._doAddButtonSheet(app, $html, data);
		});
	}
	// endregion

	constructor () {
		super({
			eventNamespace: MenuActorTitleTools._EVT_NAMESPACE,
			toolsList: MenuActorTitleTools._TOOL_LIST,
			direction: "down",
		});
	}

	_doAddButtonSheet (app, $html, data) {
		if (!UtilMigrate.isOwner(data)) return;

		const $sheetHeader = app.element.find(`.window-header`);
		$sheetHeader.find(`.tit-tool__btn-open--sheet`).remove();

		$(`<a class="tit-tool__btn-open--sheet"><span class="fas fa-toolbox"></span> Tools</a>`)
			// Prevent dragging when clicking on this button
			.mousedown(evt => evt.stopPropagation())
			.mouseup(evt => {
				evt.preventDefault();
				evt.stopPropagation();

				return this._pOpenMenu(evt, app, $html, data);
			})
			.insertBefore($sheetHeader.find(`.close`));
	}

	async _pHandleOpenButtonClick (evt, toolMeta, app, $html, data) {
		toolMeta.Class.pHandleButtonClick(evt, app, $html, data);
	}
}
MenuActorTitleTools._EVT_NAMESPACE = "plutonium-actor-title-menu--tools";
MenuActorTitleTools._TOOL_LIST = [
	{
		name: "Polymorpher",
		Class: ActorPolymorpher,
		iconClass: "fa-paw",
	},
	{
		name: "Feature/Spell Cleaner",
		Class: ActorItemCleaner,
		iconClass: "fa-trash-alt",
	},
	{
		name: "Prepared Spell Mass-Toggler",
		Class: ActorSpellPreparedToggler,
		iconClass: "fa-check-square",
	},
];

export {MenuActorTitleTools};
