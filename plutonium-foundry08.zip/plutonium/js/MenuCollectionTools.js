import {Menu} from "./Menu.js";
import {CollectionCleaner} from "./CollectionCleaner.js";
import {CollectionFolderizer} from "./CollectionFolderizer.js";
import {CollectionPermissionUpdater} from "./CollectionPermissionUpdater.js";
import {CollectionTokenUpdater} from "./CollectionTokenUpdater.js";
import {CollectionDeduplicator} from "./CollectionDeduplicator.js";
import {ImportSpecialPackages} from "./ImportSpecialPackages.js";

class MenuCollectionTools extends Menu {
	// region External
	static $getDirButton (hookName) {
		return $(`<button class="ml-0 mr-1 w-initial" title="Open tools list"><span class="fas fa-fw fa-toolbox"></span></button>`)
			.click(evt => {
				const menu = new MenuCollectionTools();
				return menu._pHandleButtonClick(evt, hookName);
			});
	}
	// endregion

	constructor () {
		super({
			eventNamespace: MenuCollectionTools._EVT_NAMESPACE,
			toolsList: MenuCollectionTools._TOOL_LIST,
			direction: "down",
		});
	}

	_pHandleButtonClick (evt, hookName) {
		evt.preventDefault();
		evt.stopPropagation();

		let type;
		switch (hookName) {
			case "renderActorDirectory": type = "actor"; break;
			case "renderItemDirectory": type = "item"; break;
			case "renderJournalDirectory": type = "journal"; break;
			case "renderRollTableDirectory": type = "rolltable"; break;
			case "renderMacroDirectory": type = "macro"; break;
			default: throw new Error(`Unhandled hook type "${hookName}"`);
		}

		return this._pOpenMenu(evt, type);
	}
}
MenuCollectionTools._EVT_NAMESPACE = "plutonium-collection-tools-menu";
MenuCollectionTools._TOOL_LIST = [
	{
		name: "Directory Cleaner",
		Class: CollectionCleaner,
		iconClass: "fa-trash-alt",
	},
	{
		name: "Directory Deduplicator",
		Class: CollectionDeduplicator,
		iconClass: "fa-object-group",
	},
	{
		name: "Bulk Directory Mover",
		Class: CollectionFolderizer,
		iconClass: "fa-sitemap",
		fnCheckRequirements: type => type !== "macro",
	},
	{
		name: "Bulk Permission Editor",
		Class: CollectionPermissionUpdater,
		iconClass: "fa-id-card",
	},
	{
		name: "Bulk Prototype Token Editor",
		Class: CollectionTokenUpdater,
		iconClass: "fa-user-circle",
		fnCheckRequirements: type => type === "actor",
	},
	null,
	{
		name: "Package Importer",
		Class: ImportSpecialPackages,
		iconClass: "fa-cube",
	},
];

export {MenuCollectionTools};
