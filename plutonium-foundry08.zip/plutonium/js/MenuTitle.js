import {Menu} from "./Menu.js";
import {Config} from "./Config.js";
import {UtilMigrate} from "./UtilMigrate.js";

class MenuTitle extends Menu {
	// region External
	static init () {
		if (!this._HOOK_NAME) throw new Error(`Missing hook name!`);

		Hooks.on(this._HOOK_NAME, (app, $html, data) => {
			const availableTools = this._TOOL_LIST.filter(it => (it.isRequireOwner && UtilMigrate.isOwner(data)) || !it.isRequireOwner);

			const menu = new this(this._EVT_NAMESPACE, availableTools);
			menu._doAddButtonSheet(app, $html, data);
		});
	}
	// endregion

	constructor (eventNamespace, toolsList) {
		if (!eventNamespace) throw new Error(`Missing namespace argument!`);
		if (!toolsList) throw new Error(`Missing tools list argument!`);

		toolsList = toolsList.filter(it => it.getMinRole == null || game.user.role >= it.getMinRole());

		super({
			eventNamespace,
			toolsList,
			direction: "down",
		});
	}

	_doAddButtonSheet (app, $html, data) {
		const $sheetHeader = app.element.find(`.window-header`);
		$sheetHeader.find(`.tit-menu__btn-open--sheet`).remove();

		$(`<a class="tit-menu__btn-open--sheet px-2" title="${Config.get("ui", "isStreamerMode") ? "Other" : "Plutonium"} Options"><span class="fas fa-ellipsis-v"></span></a>`)
			// Prevent dragging when clicking on this button
			.mousedown(evt => evt.stopPropagation())
			.mouseup(evt => {
				evt.preventDefault();
				evt.stopPropagation();

				return this._pOpenMenu(evt, app, $html, data);
			})
			.insertBefore($sheetHeader.find(`.close`));
	}

	async _pHandleOpenButtonClick (evt, toolMeta, app, $html, data) {
		toolMeta.Class.pHandleButtonClick(evt, app, $html, data);
	}
}

export {MenuTitle};
