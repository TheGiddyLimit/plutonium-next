import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleActorDirectory extends MenuTitle {}
MenuTitleActorDirectory._HOOK_NAME = "renderActorDirectory";
MenuTitleActorDirectory._EVT_NAMESPACE = "plutonium-actor-directory-title-menu";
MenuTitleActorDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleActorDirectory};
