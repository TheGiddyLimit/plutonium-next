import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleArtBrowserApp extends MenuTitle {}
MenuTitleArtBrowserApp._HOOK_NAME = "renderArtBrowserApp";
MenuTitleArtBrowserApp._EVT_NAMESPACE = "plutonium-art-browser-app-title-menu";
MenuTitleArtBrowserApp._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleArtBrowserApp};
