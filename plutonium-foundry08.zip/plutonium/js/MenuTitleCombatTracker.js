import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleCombatTracker extends MenuTitle {}
MenuTitleCombatTracker._HOOK_NAME = "renderCombatTracker";
MenuTitleCombatTracker._EVT_NAMESPACE = "plutonium-combat-tracker-title-menu";
MenuTitleCombatTracker._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleCombatTracker};
