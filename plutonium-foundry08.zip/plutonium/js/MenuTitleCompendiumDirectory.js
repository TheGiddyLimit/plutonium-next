import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleCompendiumDirectory extends MenuTitle {}
MenuTitleCompendiumDirectory._HOOK_NAME = "renderCompendiumDirectory";
MenuTitleCompendiumDirectory._EVT_NAMESPACE = "plutonium-compendium-directory-title-menu";
MenuTitleCompendiumDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleCompendiumDirectory};
