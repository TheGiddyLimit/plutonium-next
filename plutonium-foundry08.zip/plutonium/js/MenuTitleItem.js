import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";
import {ShowSheet} from "./ShowSheet.js";

class MenuTitleItem extends MenuTitle {}
MenuTitleItem._HOOK_NAME = "renderItemSheet";
MenuTitleItem._EVT_NAMESPACE = "plutonium-item-title-menu";
MenuTitleItem._TOOL_LIST = [
	{
		name: "Show Players",
		Class: ShowSheet,
		iconClass: "fa-eye",
		isRequireOwner: true,
	},
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleItem};
