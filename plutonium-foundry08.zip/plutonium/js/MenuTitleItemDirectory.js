import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleItemDirectory extends MenuTitle {}
MenuTitleItemDirectory._HOOK_NAME = "renderItemDirectory";
MenuTitleItemDirectory._EVT_NAMESPACE = "plutonium-item-directory-title-menu";
MenuTitleItemDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleItemDirectory};
