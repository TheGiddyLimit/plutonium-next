import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleJournalDirectory extends MenuTitle {}
MenuTitleJournalDirectory._HOOK_NAME = "renderJournalDirectory";
MenuTitleJournalDirectory._EVT_NAMESPACE = "plutonium-journal-directory-title-menu";
MenuTitleJournalDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleJournalDirectory};
