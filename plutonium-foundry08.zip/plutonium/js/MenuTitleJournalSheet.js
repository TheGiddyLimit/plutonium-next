import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleJournalSheet extends MenuTitle {}
MenuTitleJournalSheet._HOOK_NAME = "renderJournalSheet";
MenuTitleJournalSheet._EVT_NAMESPACE = "plutonium-journal-sheet-title-menu";
MenuTitleJournalSheet._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleJournalSheet};
