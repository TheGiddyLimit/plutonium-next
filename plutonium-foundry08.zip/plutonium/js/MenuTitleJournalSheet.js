import {MenuTitle} from "./MenuTitle.js";

class MenuTitleJournalSheet extends MenuTitle {}
MenuTitleJournalSheet._HOOK_NAME = "renderJournalSheet";
MenuTitleJournalSheet._EVT_NAMESPACE = "plutonium-journal-sheet-title-menu";
MenuTitleJournalSheet._TOOL_LIST = [];

export {MenuTitleJournalSheet};
