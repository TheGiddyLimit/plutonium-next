import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleMacroDirectory extends MenuTitle {}
MenuTitleMacroDirectory._HOOK_NAME = "renderMacroDirectory";
MenuTitleMacroDirectory._EVT_NAMESPACE = "plutonium-macro-directory-title-menu";
MenuTitleMacroDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleMacroDirectory};
