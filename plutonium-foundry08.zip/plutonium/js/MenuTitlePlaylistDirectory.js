import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitlePlaylistDirectory extends MenuTitle {}
MenuTitlePlaylistDirectory._HOOK_NAME = "renderPlaylistDirectory";
MenuTitlePlaylistDirectory._EVT_NAMESPACE = "plutonium-playlist-directory-title-menu";
MenuTitlePlaylistDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitlePlaylistDirectory};
