import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";
import {ChooseImporter} from "./ChooseImporter.js";
import {Config} from "./Config.js";

class MenuTitleRollTableConfig extends MenuTitle {}
MenuTitleRollTableConfig._HOOK_NAME = "renderRollTableConfig";
MenuTitleRollTableConfig._EVT_NAMESPACE = "plutonium-roll-table-config-title-menu";
MenuTitleRollTableConfig._TOOL_LIST = [
	{
		name: "Plutonium Import",
		streamerName: "Import",
		Class: ChooseImporter,
		iconClass: "fa-atom",
		getMinRole: () => Config.get("import", "minimumRole"),
		isRequireOwner: true,
	},
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleRollTableConfig};
