import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleRollTableDirectory extends MenuTitle {}
MenuTitleRollTableDirectory._HOOK_NAME = "renderRollTableDirectory";
MenuTitleRollTableDirectory._EVT_NAMESPACE = "plutonium-roll-table-directory-title-menu";
MenuTitleRollTableDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleRollTableDirectory};
