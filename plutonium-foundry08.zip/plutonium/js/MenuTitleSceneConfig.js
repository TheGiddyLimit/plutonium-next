import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleSceneConfig extends MenuTitle {}
MenuTitleSceneConfig._HOOK_NAME = "renderSceneConfig";
MenuTitleSceneConfig._EVT_NAMESPACE = "plutonium-scene-config-title-menu";
MenuTitleSceneConfig._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleSceneConfig};
