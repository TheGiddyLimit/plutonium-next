import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleSceneDirectory extends MenuTitle {}
MenuTitleSceneDirectory._HOOK_NAME = "renderSceneDirectory";
MenuTitleSceneDirectory._EVT_NAMESPACE = "plutonium-scene-directory-title-menu";
MenuTitleSceneDirectory._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleSceneDirectory};
