import {MenuTitle} from "./MenuTitle.js";
import {PopoutSheet} from "./PopoutSheet.js";

class MenuTitleSettings extends MenuTitle {}
MenuTitleSettings._HOOK_NAME = "renderSettings";
MenuTitleSettings._EVT_NAMESPACE = "plutonium-settings-title-menu";
MenuTitleSettings._TOOL_LIST = [
	{
		name: "Pop Out",
		Class: PopoutSheet,
		iconClass: "fa-external-link-alt",
		additionalClassesButton: "pop__mnu-btn-open",
		additionalClassesPreSpacer: "pop__mnu-btn-open",
	},
];

export {MenuTitleSettings};
