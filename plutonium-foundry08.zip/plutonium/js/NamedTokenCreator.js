import {SharedConsts} from "../shared/SharedConsts.js";
import {Vetools} from "./Vetools.js";

class NamedTokenCreator {
	static async pCreateToken ({name, xScene, yScene}) {
		if (!canvas.scene) throw new Error(`There is currently no active scene!`);

		const img = await this._pGetBlankTokenImage();
		const tokenBlob = await this._pGetTokenBlob({name, img});
		const url = await Vetools.pSaveImageToServerAndGetUrl({blob: tokenBlob, path: `named-token/${name}.png`});
		await this._pCreateToken({name, url, xScene, yScene});
	}

	static async _pGetBlankTokenImage () {
		const imgReq = await fetch(`modules/${SharedConsts.MODULE_NAME}/media/img/blank.png`);
		const imgBlob = await imgReq.blob();

		const img = new Image();
		let resolve = null;
		const pImgLoad = new Promise(resolve_ => resolve = resolve_);
		img.onload = () => resolve();
		img.src = URL.createObjectURL(imgBlob);
		await pImgLoad;

		return img;
	}

	static _pGetTokenBlob ({name, img}) {
		const cnv = document.createElement("canvas");
		cnv.width = img.width;
		cnv.height = img.height;
		const ctx = cnv.getContext("2d");
		ctx.drawImage(img, 0, 0);

		ctx.shadowColor = "#000000";
		ctx.shadowBlur = 14;

		ctx.fillStyle = "#d0c04c";
		ctx.font = `${this._BB_Y1 - this._BB_Y0}px "Modesto Condensed", "Palatino Linotype", serif`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(
			name,
			this._BB_X0 + ((this._BB_X1 - this._BB_X0) / 2),
			this._BB_Y0 + ((this._BB_Y1 - this._BB_Y0) / 2),
			this._BB_X1 - this._BB_X0,
		);

		return new Promise(resolve => {
			cnv.toBlob(blob => resolve(blob), "image/png");
		});
	}

	static _pCreateToken ({name, url, xScene, yScene}) {
		return TokenDocument.create(
			{
				name,
				x: xScene,
				y: yScene,
				img: encodeURL(url),
				width: 1,
				height: 1,
				scale: 1,
			},
			{
				parent: canvas.scene,
			},
		);
	}
}
NamedTokenCreator._BB_X0 = 31;
NamedTokenCreator._BB_X1 = 246;
NamedTokenCreator._BB_Y0 = 93;
NamedTokenCreator._BB_Y1 = 182;

export {NamedTokenCreator};
