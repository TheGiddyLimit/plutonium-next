import {Vetools} from "./Vetools.js";
import {UtilImage} from "./UtilImage.js";
import {SharedConsts} from "../shared/SharedConsts.js";

class NoteImageCreator {
	static async pCreateImageGetUrl ({name}) {
		const img = await this._pGetBlankPuckImage();
		const tokenBlob = await this._pGetPuckBlob({name, img});
		return Vetools.pSaveImageToServerAndGetUrl({blob: tokenBlob, path: `puck/${name}.png`});
	}

	static async _pGetBlankPuckImage () {
		return UtilImage.pLoadTempImage(`modules/${SharedConsts.MODULE_NAME}/media/img/puck.png`);
	}

	static _pGetPuckBlob ({name, img}) {
		return UtilImage.pDrawTextGetBlob({
			text: name,
			img,
			bbX0: NoteImageCreator._BB_X0,
			bbX1: NoteImageCreator._BB_X1,
			bbY0: NoteImageCreator._BB_Y0,
			bbY1: NoteImageCreator._BB_Y1,
			color: NoteImageCreator._COLOR_TEXT,
			font: `"Times New Roman", Times, serif`,
			isBold: true,
		});
	}
}
NoteImageCreator._COLOR_TEXT = "#010101";
NoteImageCreator._BB_X0 = 12;
NoteImageCreator._BB_X1 = 128;
NoteImageCreator._BB_Y0 = 39;
NoteImageCreator._BB_Y1 = 105;

export {NoteImageCreator};
