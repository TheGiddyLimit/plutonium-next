import {libWrapper, UtilLibWrapper} from "./PatcherLibWrapper.js";
import {SharedConsts} from "../shared/SharedConsts.js";
import {Config} from "./Config.js";

class Patcher_CanvasAnimation {
	static init () {
		libWrapper.register(
			SharedConsts.MODULE_NAME,
			"Token.prototype.setPosition",
			function (fn, x, y, opts, ...otherArgs) {
				if (Config.get("tokens", "isFastAnimations")) {
					opts = opts || {};
					opts.animate = false;
				}
				return fn(x, y, opts, ...otherArgs);
			},
			UtilLibWrapper.LIBWRAPPER_MODE_WRAPPER,
		)
	}
}

export {Patcher_CanvasAnimation};
