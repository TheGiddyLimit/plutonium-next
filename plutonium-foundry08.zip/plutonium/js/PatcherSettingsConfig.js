import {Config} from "./Config.js";
import {SharedConsts} from "../shared/SharedConsts.js";

class Patcher_SettingsConfig {
	static init () {
		Hooks.on("renderSettingsConfig", (app, $html) => {
			if (!Config.get("ui", "isStreamerMode")) return;

			const elesHeaders = $html.find(`.module-header`).get();
			for (const eleHeader of elesHeaders) {
				const node = this._findNameNode(eleHeader);
				if (!node) continue;

				node.data = "SRD";
				break;
			}
		});
	}

	/** Search for the exact text node, to avoid breaking compatibility with e.g. Tidy UI */
	static _findNameNode (ele) {
		if (!ele) return null;
		if (ele.nodeName === "#text") {
			const txt = (ele.data || "").trim();
			if (txt === SharedConsts.MODULE_TITLE) return ele;
			return null;
		}
		for (let i = 0; i < ele.childNodes.length; ++i) {
			const node = ele.childNodes[i];
			const out = this._findNameNode(node);
			if (out) return out;
		}
	}
}

export {Patcher_SettingsConfig};
