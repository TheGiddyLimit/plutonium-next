import {libWrapper, UtilLibWrapper} from "./PatcherLibWrapper.js";
import {SharedConsts} from "../shared/SharedConsts.js";
import {Config} from "./Config.js";
import {ChooseImporter} from "./ChooseImporter.js";
import {LGT} from "./Util.js";
import {UtilApplications} from "./UtilApplications.js";
import {UtilEvents} from "./UtilEvents.js";
import {UtilPatch} from "./UtilPatch.js";
import {UtilGameSettings} from "./UtilGameSettings.js";

class Patcher_TextEditor {
	static init () {
		libWrapper.register(
			SharedConsts.MODULE_NAME,
			"TextEditor.enrichHTML",
			function (fnEnrichHtml, ...args) {
				if (!Config.get("journalEntries", "isEnableJournalEmbeds") && !Config.get("journalEntries", "isEnableContentLinks")) return fnEnrichHtml(...args);
				return Patcher_TextEditor.enrichHTML(fnEnrichHtml, ...args);
			},
			UtilLibWrapper.LIBWRAPPER_MODE_WRAPPER,
		);

		libWrapper.register(
			SharedConsts.MODULE_NAME,
			"JournalSheet.prototype._disableFields",
			function (fnDisableFields, ...args) {
				const res = fnDisableFields(...args);
				if (!Config.get("journalEntries", "isEnableJournalEmbeds")) return res;
				Patcher_TextEditor.Embed._doEnableToggleButtons(...args);
				return res;
			},
			UtilLibWrapper.LIBWRAPPER_MODE_WRAPPER,
		);

		$(document.body)
			.on("click", `.jemb__btn-toggle`, evt => {
				Patcher_TextEditor.Embed.handleToggleClick(evt);
			})
			.on("click", `.jlnk__entity-link`, evt => {
				Patcher_TextEditor.ContentLoader.handleClick(evt);
			});

		Patcher_TextEditor.ContentDragDrop.init();
	}

	/** Based on the original method. */
	static enrichHTML (originalEnrichHtml, content, opts, depth = 0) {
		opts = opts || {};

		if (opts.secrets === undefined) opts.secrets = false;
		if (opts.entities === undefined) opts.entities = true;
		if (opts.links === undefined) opts.links = true;
		if (opts.rolls === undefined) opts.rolls = true;

		// Call the original method--"content" is now enriched HTML
		content = originalEnrichHtml(content, opts);

		// If we are not to replace dynamic entity links, return the base content
		if (!opts.entities) return content;

		// Don't load compendiums--we don't match `EmbedCompendium`
		content = content
			.replace(/@Embed(JournalEntry)\[([^\]]+)](?:{([^}]+)})?/g, (...m) => Patcher_TextEditor.Embed.getHtml(opts, depth, ...m))
			.replace(/@([a-zA-Z]+)\[([^\]]+)](?:{([^}]+)})?/g, (...m) => Patcher_TextEditor.ContentLoader.getHtml(opts, depth, ...m))
		;

		return content;
	}
}

Patcher_TextEditor.Embed = class {
	static getHtml (enrichOpts, depth, fullText, entityType, entityNameOrId, displayText) {
		const config = CONFIG[entityType];
		const collection = config.collection.instance;
		const entity = this._getEntity(collection, entityNameOrId);

		if (!entity) return `<a class="entity-link broken"><i class="fas fa-unlink"></i> ${displayText || entityNameOrId}</a>`;
		if (this._getEntityPermissions(entity) < CONST.ENTITY_PERMISSIONS.OBSERVER) return `<a class="entity-link broken"><i class="fas fa-unlink"></i> ${displayText || entityNameOrId} <i>(you do not have sufficient permissions to view this journal entry)</i></a>`;

		// Get the standard Foundry link
		const htmlJournalLink = TextEditor._createContentLink(fullText, entityType, entityNameOrId, displayText).outerHTML;

		const isAutoExpand = Config.get("journalEntries", "isAutoExpandJournalEmbeds");
		if (entity.sheet._sheetMode === "image") {
			const img = entity.data.img;
			return `<div class="w-100 flex-col">
				<div class="flex-v-center mb-1 jemb__wrp-lnk">${htmlJournalLink}${this._getBtnHtmlToggle(isAutoExpand)}</div>
				<div class="flex-vh-center jemb__wrp-content ${isAutoExpand ? "" : "ve-hidden"}"><a target="_blank w-100" href="${img}"><img src="${img}" class="jemb__img"></a></div>
			</div>`;
		} else {
			// Avoid infinite loops
			const isTooDeep = depth === Patcher_TextEditor.Embed._MAX_RECURSION_DEPTH;
			const subContent = isTooDeep ? entity.data.content : TextEditor.enrichHTML(entity.data.content, enrichOpts, depth + 1);
			return `<div class="w-100 flex-col">
				<div class="flex-v-center mb-1 jemb__wrp-lnk">${htmlJournalLink}${this._getBtnHtmlToggle(isAutoExpand)}</div>
				${isTooDeep ? `<div class="mb-1 bold veapp__msg-error">Warning: too many recursive embeds! Have you made an infinite loop?</div>` : ""}
				<div class="w-100 jemb__wrp-content ${isAutoExpand ? "" : "ve-hidden"}">${subContent}</div>
			</div>`;
		}
	}

	static _getEntityPermissions (entity) {
		if (game.user.isGM) return CONST.ENTITY_PERMISSIONS.OWNER;
		return Math.max(entity.data.permission[game.user.id], entity.data.permission["default"]);
	}

	static _getEntity (collection, entityNameOrId) {
		// Match either on ID or by name
		let entity = null;
		if (/^[a-zA-Z0-9]{16}$/.test(entityNameOrId)) entity = collection.get(entityNameOrId);
		if (!entity) entity = collection.contents.find(e => e.data.name === entityNameOrId);
		return entity;
	}

	static handleToggleClick (event) {
		const $btn = $(event.currentTarget);
		const isExpanded = $btn.attr("data-plut-is-expanded") === "1";

		if (event.shiftKey) {
			event.preventDefault();

			const $editor = $btn.closest(`.editor`);
			$editor.find(`button[data-plut-is-expanded]`).each((i, e) => this._handleExpandCollapse($(e), isExpanded));
			return;
		}

		this._handleExpandCollapse($btn, isExpanded);
	}

	static _handleExpandCollapse ($btn, isExpanded) {
		const $wrp = $btn.parent().next();
		$wrp.toggleClass("ve-hidden", isExpanded);
		$btn
			.attr("data-plut-is-expanded", isExpanded ? "0" : "1")
			.html(isExpanded ? `<i class="fa fa-caret-square-left"></i>` : `<i class="fa fa-caret-square-down"></i>`)
			.title(`${isExpanded ? `Expand` : `Collapse`} Journal Entry (SHIFT for All Entries)`);
	}

	static _getBtnHtmlToggle (isAutoExpand) {
		return `<button class="btn btn-xxs btn-5et btn-default flex-vh-center mx-1 jemb__btn-toggle" data-plut-is-expanded="${isAutoExpand ? 1 : 0}" title="${isAutoExpand ? "Collapse" : "Expand"} Journal Entry (SHIFT for All Entries)" type="button">${isAutoExpand ? `<i class="fa fa-caret-square-down"></i>` : `<i class="fa fa-caret-square-left"></i>`}</button>`
	}

	/** Based on `FormApplication._disableFields` */
	static _doEnableToggleButtons (form) {
		for (let el of form.getElementsByTagName("BUTTON")) {
			if (el.classList.contains("jemb__btn-toggle")) el.removeAttribute("disabled");
		}
	}
}
Patcher_TextEditor.Embed._MAX_RECURSION_DEPTH = 69; // Arbitrary number of steps

Patcher_TextEditor.ContentLoader = class {
	static getHtml (enrichOpts, depth, fullText, tag, pipeParts, displayText) {
		if (Patcher_TextEditor.ContentLoader._STATIC_TAGS.has(tag)) return this._getHtml_staticTag(enrichOpts, depth, fullText, tag, pipeParts, displayText);

		const Importer = ChooseImporter.getImporterClassMeta(tag)?.Class;

		const name = (Renderer.splitTagByPipe(pipeParts)[0] || "");

		if (!Importer) return `<a class="entity-link broken" title="Unknown Tag &quot;${tag.qq()}&quot;"><i class="fas fa-unlink"></i> ${StrUtil.qq(displayText || name)}</a>`;

		const config = CONFIG[Importer.FOLDER_TYPE];

		// (Should never occur)
		if (!config) return `<a class="entity-link broken" title="No CONFIG found for type &quot;${Importer.FOLDER_TYPE}&quot;\u2014this is a bug!"><i class="fas fa-unlink"></i> ${StrUtil.qq(displayText || name)}</a>`;

		const {displayText: displayTextPipe, page, source, hash, preloadId, hashPreEncoded, hashHover, hashPreEncodedHover} = Renderer.utils.getTagMeta(`@${tag}`, pipeParts);

		return `<a class="jlnk__entity-link" draggable="true" ${Config.get("journalEntries", "isEnableHoverForLinkTags") ? `data-plut-hover="${true}"` : `title="SHIFT-Click to Import"`} data-plut-hover-page="${page.qq()}" data-plut-hover-source="${source.qq()}" data-plut-hover-hash="${hash.qq()}" data-plut-hover-tag="${tag}" ${preloadId ? `data-plut-hover-preload-id="${preloadId.qq()}"` : ""} ${hashPreEncoded ? `data-plut-hover-hash-pre-encoded="${hashPreEncoded}"` : ""} ${hashHover ? `data-plut-hover-hash-hover="${hashHover.qq()}"` : ""} ${hashPreEncodedHover ? `data-plut-hover-hash-pre-encoded-hover="${hashPreEncodedHover}"` : ""} data-plut-rich-link="${true}" data-plut-rich-link-entity-type="${Importer.FOLDER_TYPE}" data-plut-rich-link-original-text="${fullText.slice(1).qq()}"><i class="fas ${config.sidebarIcon}"></i> ${StrUtil.qq(displayTextPipe || displayText || name)}</a>`;
	}

	static _getHtml_staticTag (enrichOpts, depth, fullText, tag, pipeParts, displayText) {
		const expander = tag === "skill" ? Parser.skillToExplanation : tag === "sense" ? Parser.senseToExplanation : null;

		const [name, displayTextTag] = Renderer.splitTagByPipe(pipeParts);
		const entries = expander ? expander(name) : null;
		if (!expander || entries === name || CollectionUtil.deepEquals(entries, expander(""))) return `<a class="entity-link broken" title="Unknown ${tag}"><i class="fas fa-unlink"></i> ${StrUtil.qq(displayTextTag || displayText || name)}</a>`;

		return `<a class="jlnk__entity-link" draggable="true" ${Config.get("journalEntries", "isEnableHoverForLinkTags") ? `data-plut-hover="${true}"` : ``} data-plut-hover-preload-uid="${CryptUtil.uid()}" data-plut-hover-tag="${tag}" data-plut-hover-pipe-parts="${pipeParts.qq()}" data-plut-rich-link-original-text="${fullText.slice(1).qq()}"><i class="fas fa-info-circle"></i> ${StrUtil.qq(displayTextTag || displayText || name)}</a>`;
	}

	static handleClick (evt) {
		evt.stopPropagation();
		evt.preventDefault();

		// The "@" is stripped to avoid issues when recursively rendering embedded text, so add it back here
		const originalText = `@${evt.currentTarget.dataset.plutRichLinkOriginalText}`;

		const tag = evt.currentTarget.dataset.plutHoverTag;
		const page = evt.currentTarget.dataset.plutHoverPage;
		const source = evt.currentTarget.dataset.plutHoverSource;
		let hash = evt.currentTarget.dataset.plutHoverHash;
		const preloadId = evt.currentTarget.dataset.plutHoverPreloadId;
		const hashPreEncoded = !!evt.currentTarget.dataset.plutHoverHashPreEncoded;

		if (!page || !source || !hash) return;
		const importer = ChooseImporter.getImporter(tag) || ChooseImporter.getImporter(page);

		if (!hashPreEncoded) hash = UrlUtil.encodeForHash(hash);

		const isPermanent = !!evt.shiftKey && game.user.can("ACTOR_CREATE");

		Renderer.hover.pCacheAndGet(page, source, hash)
			.then(ent => {
				const msgErrorBase = `Could not load content for tag "${originalText}"!`;

				if (!ent) {
					const msgError = `${msgErrorBase} Could not find matching entity.`;
					console.error(...LGT, msgError);
					return ui.notifications.error(msgError);
				}

				importer.pImportEntry(ent, {isTemp: !isPermanent})
					.then(result => {
						if (isPermanent) UtilApplications.doShowImportedNotification(result);

						(result.imported || []).forEach(fvttEnt => {
							if (fvttEnt.sheet) return fvttEnt.sheet.render(true);
							fvttEnt.render(true);
						});
					})
					.catch(err => {
						console.error(...LGT, err);
						ui.notifications.error(`${msgErrorBase} ${VeCt.STR_SEE_CONSOLE}`)
					});
			});
	}
}
Patcher_TextEditor.ContentLoader._STATIC_TAGS = new Set(["skill", "sense"])

/** Drag-and-drop for @tag links. */
Patcher_TextEditor.ContentDragDrop = class {
	static init () {
		libWrapper.register(
			SharedConsts.MODULE_NAME,
			"ActorSheet.prototype._onDragStart",
			function (fn, ...args) {
				const evt = args[0];
				if (evt.target.dataset.plutRichLink) return;
				return fn(...args);
			},
			UtilLibWrapper.LIBWRAPPER_MODE_MIXED,
		);

		if (!UtilGameSettings.getSafe("core", "noCanvas")) {
			libWrapper.register(
				SharedConsts.MODULE_NAME,
				"canvas.tokens._onDropActorData",
				async function (fn, ...args) {
					return Patcher_TextEditor.ContentDragDrop._pHandleCanvasDrop({fn, args});
				},
				UtilLibWrapper.LIBWRAPPER_MODE_WRAPPER,
			);

			libWrapper.register(
				SharedConsts.MODULE_NAME,
				"canvas.notes._onDropData",
				async function (fn, ...args) {
					return Patcher_TextEditor.ContentDragDrop._pHandleCanvasDrop({fn, args});
				},
				UtilLibWrapper.LIBWRAPPER_MODE_WRAPPER,
			);
		}

		// region Unfortunately [and probably for the best], libWrapper doesn't work here, so directly overwrite the method.
		const ActorSheet5eCharacter = MiscUtil.get(CONFIG.Actor, "sheetClasses", "character", "dnd5e.ActorSheet5eCharacter", "cls");
		if (ActorSheet5eCharacter) {
			const baseClassActor = Object.getPrototypeOf(ActorSheet5eCharacter);

			const cachedActorSheetDropActor = UtilPatch.cacheMethod(baseClassActor.prototype, "_onDropActor");
			baseClassActor.prototype._onDropActor = async function (...args) {
				return Patcher_TextEditor.ContentDragDrop._pHandleActorDrop({fn: cachedActorSheetDropActor.bind(this), args});
			}

			const cachedActorSheetDropItem = UtilPatch.cacheMethod(baseClassActor.prototype, "_onDropItem");
			baseClassActor.prototype._onDropItem = async function (...args) {
				return Patcher_TextEditor.ContentDragDrop._pHandleActorDrop({fn: cachedActorSheetDropItem.bind(this), args});
			}
		} else {
			console.warn(...LGT, `Could not find "dnd5e.ActorSheet5eCharacter" sheet. Are you using a non-dnd5e system?`);
		}
		// endregion

		libWrapper.register(
			SharedConsts.MODULE_NAME,
			"TextEditor._onDropEditorData",
			async function (fn, ...args) {
				return Patcher_TextEditor.ContentDragDrop._pHandleEditorDrop({fn, args});
			},
			UtilLibWrapper.LIBWRAPPER_MODE_MIXED,
		);
	}

	static async _pHandleCanvasDrop ({fn, args}) {
		const [, data] = args;
		return this._pMutDropDataId({fn, args, data});
	}

	static async _pHandleActorDrop ({fn, args}) {
		const [, data] = args;
		return this._pMutDropDataId({fn, args, data, isTemp: true});
	}

	static async _pHandleEditorDrop ({fn, args}) {
		const [evt, editor] = args;
		evt.preventDefault();

		const data = Patcher_TextEditor.ContentDragDrop._getEvtData(evt);
		if (!data) return;

		if (data?.subType !== UtilEvents.EVT_DATA_SUBTYPE__HOVER) return fn(...args);

		editor.insertContent(data.originalText);
	}

	static async _pMutDropDataId ({fn, args, data, isTemp = false}) {
		if (data?.subType !== UtilEvents.EVT_DATA_SUBTYPE__HOVER) return fn(...args);

		const importer = ChooseImporter.getImporter(data.page);
		if (!importer) return;

		const ent = await Renderer.hover.pCacheAndGet(data.page, data.source, data.hash, {isCopy: true});
		if (!ent) return;

		const packName = `${SharedConsts.MODULE_NAME}-temp-${importer.constructor.FOLDER_TYPE.toLowerCase()}`;
		const packKey = `world.${packName}`;
		if (isTemp) {
			let pack = game.packs.get(packKey);
			if (!pack) {
				pack = await CompendiumCollection.createCompendium({
					entity: importer.constructor.FOLDER_TYPE,
					label: `Temp ${importer.constructor.FOLDER_TYPE}`,
					name: packName,
					package: "world",
				});
			}
			importer.pack = pack;
			data.pack = packKey;
		}

		const importResult = await importer.pImportEntry(ent);
		const imported = importResult.imported[0];
		data.id = imported.id;

		try {
			return (await fn(...args));
		} finally {
			if (isTemp) {
				const pack = game.packs.get(packKey);
				pack.delete();
			}
		}
	}

	static _getEvtData (evt) {
		try {
			return JSON.parse(evt.dataTransfer.getData("text/plain"));
		} catch (e) {
			return null;
		}
	}
}

export {Patcher_TextEditor};
