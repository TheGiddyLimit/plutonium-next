import {Config} from "./Config.js";
import {LGT} from "./Util.js";
import {UtilApplications} from "./UtilApplications.js";
import {UtilActors} from "./UtilActors.js";

class RivetBridge {
	static init () {
		window.addEventListener("rivet.receive", evt => {
			console.log(...LGT, `Received Rivet message (JSON)`);
			return this._handlePacket(evt.detail);
		});

		window.addEventListener("rivet.receive-text", () => {
			console.log(...LGT, `Received Rivet message (text)`);
			const $ipts = $(`textarea.rivet-transfer`);
			const packetRaw = $ipts.last().val();
			$ipts.remove();
			return this._handlePacket(JSON.parse(packetRaw));
		});
	}

	static _handlePacket (pack) {
		switch (pack.type) {
			case "roll": return this._handleRollMessage(pack);
			case "entity": return this._pHandleEntityMessage(pack);
			case "currency": return this._pHandleCurrencyMessage(pack);
			case "5etools.lootgen.loot": return this._pHandleSpecialMessage_5etools_lootgen_loot(pack);
			default: ui.notifications.error(`Unhandled Rivet message with type "${pack.type}"! You may need to update your extension.`);
		}
	}

	static _handleRollMessage (pack) {
		const data = pack.data;

		if (!pack.settings.isSendRolls) return;

		const roll = new Roll(data.dice);

		const whisper = [];
		if (pack.settings.isWhisper) whisper.push(game.userId);

		roll.toMessage({
			speaker: {
				alias: data.rolledBy,
			},
			flavor: data.label,
			rollMode: "roll",
			whisper,
		});
	}

	/** Import an entity. */
	static async _pHandleEntityMessage (pack) {
		const minRole = Config.get("import", "minimumRole");
		if (game.user.role < minRole) return;

		const data = pack.data;
		const actor = this._getTargetActor();

		const {ChooseImporter} = await import("./ChooseImporter.js");
		const importer = ChooseImporter.getImporter(data?.entity?.__prop || data.page, actor);
		if (!importer) return ui.notifications.error(`Plutonium does not yet support entities from "${data.page}"! You may need to update your extension.`);
		try {
			await importer.pInit();
			const opts = {...(data.options || {})};
			if (data.isTemp) opts.isTemp = true;
			const importedMeta = await importer.pImportEntry(data.entity, opts);
			UtilApplications.doShowImportedNotification(importedMeta);
		} catch (e) {
			UtilApplications.doShowImportedNotification({entity: data, status: UtilApplications.TASK_EXIT_FAILED});
			setTimeout(() => { throw e; });
		}
	}

	static async _pHandleCurrencyMessage (pack) {
		const data = pack.data;
		const actor = this._getTargetActor();

		if (!actor) {
			await ChatMessage.create({
				content: `<div>Currency: ${Parser.getDisplayCurrency(data.currency)}</div>`,
				user: game.userId,
				type: 4,
				speaker: {alias: "Rivet"},
				whisper: game.users.contents.filter(it => it.isGM || it === game.user).map(it => it.id),
			});
			return;
		}

		try {
			await UtilActors.pAddCurrencyToActor({currency: data.currency, actor});
			ui.notifications.info(`Applied currency "${Parser.getDisplayCurrency(data.currency)}" to actor "${actor.name}"`);
		} catch (e) {
			ui.notifications.error(`Failed to apply currency "${Parser.getDisplayCurrency(data.currency)}" to actor "${actor.name}"`);
			setTimeout(() => { throw e; });
		}
	}

	static async _pHandleSpecialMessage_5etools_lootgen_loot (pack) {
		const data = pack.data;
		const actor = this._getTargetActor();

		const {ChooseImporter} = await import("./ChooseImporter.js");
		const cacheImporter = {}; // Re-use the same importer(s) for multiple item/spells

		try {
			if (data.currency && actor) await UtilActors.pAddCurrencyToActor({currency: data.currency, actor});

			const baseOpts = {};
			if (data.isTemp) baseOpts.isTemp = true;

			const importSummaries = [];
			for (const {page, entity, options} of data.entityInfos || []) {
				const pageOrProp = page || entity.__prop;
				if (!cacheImporter[pageOrProp]) {
					cacheImporter[pageOrProp] = ChooseImporter.getImporter(pageOrProp, actor)
					await cacheImporter[pageOrProp].pInit();
				}

				const importer = cacheImporter[pageOrProp];
				const importOpts = {...baseOpts, ...(options || {})};
				importSummaries.push(await importer.pImportEntry(entity, importOpts))
			}

			let errorMessage = "";
			const lisImportedDatas = importSummaries
				.map(importSummary => {
					return (importSummary.imported || [])
						.map(importedDocument => {
							// Imported to an actor sheet; link the embedded item
							if (importedDocument.embeddedDocument && importedDocument.actor) {
								return `<li class="py-1">@ActorEmbeddedItem[${importedDocument.actor.id}][${importedDocument.embeddedDocument.id}]</li>`;
							}

							// Imported to a directory/compendium; link the item
							if (importedDocument.document) {
								if (importedDocument.pack) {
									return `<li class="py-1">@Compendium[${importedDocument.pack.metadata.package}.${importedDocument.pack.metadata.name}.${importedDocument.document.id}]</li>`;
								}
								return `<li class="py-1">@Item[${importedDocument.document.id}]</li>`;
							}

							errorMessage = `Unhandled imported document type--${Object.entries(importedDocument).map(([k, v]) => `${k}=${!!v}`).join(", ")}`;
						});
				})
				.flat();
			if (errorMessage) {
				console.error(...LGT, errorMessage);
				ui.notifications.error(`Error occurred during item linking! ${VeCt.STR_SEE_CONSOLE}`);
			}

			await ChatMessage.create({
				content: `<div>
					${actor ? `<p><i>Added to the inventory of:</i> @Actor[${actor.id}]</p>` : ""}
					<ul>
						${data.currency ? `<li class="py-1">Currency: ${Parser.getDisplayCurrency(data.currency)}</li>` : ""}
						${lisImportedDatas.join("")}
					</ul>
				</div>`,
				user: game.userId,
				type: 4,
				speaker: {
					alias: "Loot Generator",
				},
				whisper: game.users.contents.filter(it => it.isGM || it === game.user).map(it => it.id),
			});

			ui.notifications.info(`Imported loot${actor ? ` to actor "${actor.name}"` : ""}!`)
		} catch (e) {
			ui.notifications.error(`Failed to import loot${actor ? ` to actor "${actor.name}"` : ""}. ${VeCt.STR_SEE_CONSOLE}`);
			setTimeout(() => { throw e; });
		}
	}

	static _getTargetActor () {
		const targetActorId = (Config.get("rivet", "targetActorId") || "").trim();
		return targetActorId ? CONFIG.Actor.collection.instance.get(targetActorId) : null;
	}
}

export {RivetBridge};
