import {LGT} from "./Util.js";
import {Config} from "./Config.js";
import {ConfigConsts} from "./ConfigConsts.js";

class TokenHpRoller {
	static init () {
		Hooks.on("createToken", async (docToken) => {
			const rollMode = Config.get("tokens", "npcHpRollMode");
			if (rollMode === ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_NONE) return;

			if (
				docToken.actor?.type !== "npc"
				|| docToken.isLinked
				|| !docToken.actor?.data?.data?.attributes?.hp?.formula
			) return;

			const roll = new Roll(docToken.actor.data.data.attributes.hp.formula);
			try {
				await roll.evaluate({
					async: true,
					minimize: rollMode === ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_MIN,
					maximize: rollMode === ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_MAX,
				});
				const messageRollMode = this._getMessageRollMode(rollMode);
				if (messageRollMode) roll.toMessage({}, {rollMode: messageRollMode});
			} catch (e) {
				console.warn(...LGT, `Failed to roll HP formula "${docToken.actor.data.data.attributes.hp.formula}" for token "${docToken.name}" (${docToken.id})! The default HP value will be used instead.`);
				return;
			}

			await docToken.actor.update({
				data: {
					attributes: {
						hp: {
							value: roll.total,
							max: roll.total,
						},
					},
				},
			});
		});
	}

	static _getMessageRollMode (rollMode) {
		switch (rollMode) {
			case ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_STANDARD: return "roll";
			case ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_GM: return "gmroll";
			case ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_BLIND: return "blindroll";
			case ConfigConsts.C_TOKEN_NPC_HP_ROLL_MODE_SELF: return "selfroll";
			default: return null;
		}
	}
}

export {TokenHpRoller};
