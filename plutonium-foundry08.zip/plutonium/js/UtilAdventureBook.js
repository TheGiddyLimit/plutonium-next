import {Vetools} from "./Vetools.js";

class UtilAdventureBook {
	static doProcessNode_mutAddMaps (
		{
			availableMaps,
			entryIdToMap,
			entryIdToName,
			entry,
			source,
		},
	) {
		if (entry.id && entry.name) entryIdToName[entry.id] = entry.name;

		if (entry.type !== "image" || !UtilAdventureBook._IMPORTABLE_IMAGE_TYPES__MAP.has(entry.imageType)) return;

		const url = Vetools.getImageUrl(entry);
		if (!url) return; // Should never occur

		const mapEntry = MiscUtil.getOrSet(availableMaps, entry.imageType, url, MiscUtil.copy(entry));
		mapEntry.title = mapEntry.title || entry.title;

		mapEntry._url = url;

		// Add source for importers, etc. Note that we do not add a name here, as we will add it in `mutMapNames`.
		mapEntry.source = mapEntry.source || source;

		if (entry.id) entryIdToMap[entry.id] = MiscUtil.copy(entry);
	}

	/**
	 * A post-processing step once all entries have been indexed in the `entryToIdMap`.
	 */
	static mutMapNames ({availableMaps, entryIdToMap, entryIdToName}) {
		Object.values(availableMaps)
			.forEach(urlToEntry => {
				Object.values(urlToEntry)
					.forEach(entry => {
						this._mutMapNames_entry({entryIdToMap, entryIdToName, entry});
					});
			});
	}

	static _mutMapNames_entry ({entryIdToMap, entryIdToName, entry}) {
		// region Add names to map regions
		if (entry.mapRegions) {
			entry.mapRegions.forEach(it => {
				it.name = it.name || entryIdToName[it.area];
			});
		}
		// endregion

		const parentEntry = entry.mapParent?.id ? entryIdToMap[entry.mapParent.id] : null;
		if (parentEntry) this._mutMapNames_entry({entryIdToMap, entryIdToName, entry: parentEntry});

		// Add name for importers, etc.
		entry.name = this._getMapName({entry, parentEntry});

		// Add parent entry, if it exists, for map region import
		entry._parentEntry = parentEntry;
	}

	static _getMapName ({entry, parentEntry}) {
		if (entry.mapName) return entry.mapName;

		// TODO(Future) consider walking back through the entry tree to fetch the name of the closest named parent entry
		//   and using its name, instead of "Unnamed Map".
		const name = entry.title || UtilAdventureBook._DEFAULT_MAP_NAME;

		if (!parentEntry || !parentEntry.title) return name;

		// If the map's just called "Player Version" (or some similar variant), use the parent name
		const entryTitleClean = (entry.title || "").replace(/[^a-zA-Z]+/g, "");
		if (!/^player(?:version)?$/i.test(entryTitleClean)) return name;

		return `${parentEntry.title} (Player Version)`;
	}
}
UtilAdventureBook._IMPORTABLE_IMAGE_TYPES__MAP = new Set(["map", "mapPlayer"]);
UtilAdventureBook._DEFAULT_MAP_NAME = "(Unnamed Map)";

export {UtilAdventureBook};
