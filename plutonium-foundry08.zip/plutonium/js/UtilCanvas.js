class UtilCanvas {
	/**
	 * @param evt
	 * @param layerName One of: "BackgroundLayer", "DrawingsLayer", "GridLayer", "WallsLayer", "TemplateLayer",
	 * "NotesLayer", "TokenLayer", "ForegroundLayer", "SoundsLayer", "LightingLayer", "SightLayer", "EffectsLayer",
	 * "ControlsLayer"
	 * @return {{x: *, y: *}}
	 */
	static getPosCanvasSpace (evt, layerName) {
		const layer = canvas.layers.find(it => it.name === layerName);

		// (Taken from `_onDropActorData`)
		// Acquire cursor position transformed to Canvas coordinates
		const [x, y] = [evt.clientX, evt.clientY];
		const t = layer.worldTransform;
		const tx = (x - t.tx) / canvas.stage.scale.x;
		const ty = (y - t.ty) / canvas.stage.scale.y;
		const p = canvas.grid.getTopLeft(tx, ty);

		return {x: p[0], y: p[1]};
	}
}

export {UtilCanvas};
