import {UtilActors} from "./UtilActors.js";

class UtilDataConverter {
	static async pGetItemWeaponType (uid) {
		uid = uid.toLowerCase().trim();

		if (UtilActors.WEAPONS_MARTIAL.includes(uid)) return "martial";
		if (UtilActors.WEAPONS_SIMPLE.includes(uid)) return "simple";

		let [name, source] = Renderer.splitTagByPipe(uid);
		source = source || "phb";
		const hash = UrlUtil.URL_TO_HASH_BUILDER[UrlUtil.PG_ITEMS]({name, source});

		if (Renderer.hover.isCached(UrlUtil.PG_ITEMS, source, hash)) return Renderer.hover.getFromCache(UrlUtil.PG_ITEMS, source, hash)?.weaponCategory;

		// If the item *probably* isn't available, return null. This prevents us from re-running the cache if we're
		//   looking for e.g. a string which isn't an item UID.
		if (Renderer.hover.isPageSourceCached(UrlUtil.PG_ITEMS, source)) return null;

		// If we've yet to attempt to load this source, load the item, and hopefully return the type
		const found = await Renderer.hover.pCacheAndGet(UrlUtil.PG_ITEMS, source, hash);
		return found?.weaponCategory;
	}
}
UtilDataConverter.WALKER_READONLY_GENERIC = MiscUtil.getWalker({isNoModification: true, keyBlacklist: MiscUtil.GENERIC_WALKER_ENTRIES_KEY_BLACKLIST});
UtilDataConverter.WALKER_GENERIC = MiscUtil.getWalker({keyBlacklist: MiscUtil.GENERIC_WALKER_ENTRIES_KEY_BLACKLIST});

export {UtilDataConverter}
