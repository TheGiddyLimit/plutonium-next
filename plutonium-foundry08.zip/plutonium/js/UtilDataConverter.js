import {UtilActors} from "./UtilActors.js";
import {Config} from "./Config.js";

class UtilDataConverter {
	static async pGetItemWeaponType (uid) {
		uid = uid.toLowerCase().trim();

		if (UtilActors.WEAPONS_MARTIAL.includes(uid)) return "martial";
		if (UtilActors.WEAPONS_SIMPLE.includes(uid)) return "simple";

		let [name, source] = Renderer.splitTagByPipe(uid);
		source = source || "phb";
		const hash = UrlUtil.URL_TO_HASH_BUILDER[UrlUtil.PG_ITEMS]({name, source});

		if (Renderer.hover.isCached(UrlUtil.PG_ITEMS, source, hash)) return Renderer.hover.getFromCache(UrlUtil.PG_ITEMS, source, hash)?.weaponCategory;

		// If the item *probably* isn't available, return null. This prevents us from re-running the cache if we're
		//   looking for e.g. a string which isn't an item UID.
		if (Renderer.hover.isPageSourceCached(UrlUtil.PG_ITEMS, source)) return null;

		// If we've yet to attempt to load this source, load the item, and hopefully return the type
		const found = await Renderer.hover.pCacheAndGet(UrlUtil.PG_ITEMS, source, hash);
		return found?.weaponCategory;
	}

	static async pGetClassItemClassAndSubclass ({sheetItem, cache = null} = {}) {
		cache = cache || {};
		if (!cache._allClasses && !cache._allSubclasses) {
			const classData = await DataUtil.class.loadJSON();
			const brew = await BrewUtil.pAddBrewData();
			cache._allClasses = [...(classData.class || []), ...(brew?.class || [])];
			cache._allSubclasses = [...(classData.subclass || []), ...(brew?.subclass || [])];
		}

		const nameLowerClean = sheetItem.name.toLowerCase().trim();
		const sourceLowerClean = (UtilDataConverter.getItemSource(sheetItem) || "").toLowerCase();

		const matchingClasses = cache._allClasses.filter(cls =>
			cls.name.toLowerCase() === nameLowerClean
				&& (
					!Config.get("import", "isStrictMatching")
					|| sourceLowerClean === Parser.sourceJsonToAbv(cls.source).toLowerCase()
				),
		);
		if (!matchingClasses.length) return {matchingClasses: [], matchingSubclasses: [], sheetItem};

		if (!(sheetItem.data.data.subclass || "").trim()) return {matchingClasses, matchingSubclasses: [], sheetItem};

		const matchingSubclasses = matchingClasses
			.map(cls => cache._allSubclasses.filter(sc => sc.className === cls.name && sc.classSource === cls.source && sc.name.toLowerCase() === sheetItem.data.data.subclass.toLowerCase().trim()))
			.flat();
		return {matchingClasses, matchingSubclasses, sheetItem};
	}

	static getItemSource (itm) {
		let data = itm.data || {};
		if (data.data) data = data.data;
		let rawSource = data.source;

		// region vtta-dndbeyond workaround
		// This is invalid, but as of 2020-12-15, vtta-dndbeyond can create an array of sources on race items on imported
		//   characters. Tolerate it.
		if (rawSource instanceof Array) rawSource = rawSource[0];
		// endregion

		if (!rawSource) return rawSource;
		return rawSource.split(UtilDataConverter._SOURCE_PAGE_PREFIX_RE)[0].trim();
	}
}
UtilDataConverter.WALKER_READONLY_GENERIC = MiscUtil.getWalker({isNoModification: true, keyBlacklist: MiscUtil.GENERIC_WALKER_ENTRIES_KEY_BLACKLIST});
UtilDataConverter.WALKER_GENERIC = MiscUtil.getWalker({keyBlacklist: MiscUtil.GENERIC_WALKER_ENTRIES_KEY_BLACKLIST});
UtilDataConverter.SOURCE_PAGE_PREFIX = " pg. ";
UtilDataConverter._SOURCE_PAGE_PREFIX_RE = new RegExp(`${UtilDataConverter.SOURCE_PAGE_PREFIX}\\d+`);

export {UtilDataConverter}
