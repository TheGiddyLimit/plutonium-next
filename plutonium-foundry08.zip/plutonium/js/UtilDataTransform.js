class UtilDataTransform {
	static _RECHARGE_TYPES = {
		"round": null,
		"restShort": "sr",
		"restLong": "lr",
		"dawn": "day",
		"dusk": "day",
		"midnight": "day",
		"special": null,
	};

	static getFvttUsesPer (it, {isStrict = true} = {}) {
		if (isStrict && !UtilDataTransform._RECHARGE_TYPES[it]) return null;
		return Parser._parse_aToB(UtilDataTransform._RECHARGE_TYPES, it);
	}
}

export {UtilDataTransform};
