import {UtilActors} from "./UtilActors.js";
import {SharedConsts} from "../shared/SharedConsts.js";

class UtilEvents {
	static init () {
		$(document.body)
			.on(`click`, `[${UtilEvents.LINK_DATA_SHEET_ITEM}]`, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				const $this = $(this);
				const data = JSON.parse($this.attr(UtilEvents.LINK_DATA_SHEET_ITEM));
				UtilActors.doShowSheetItem(evt, data.actorId, data.itemId);
			})

			.on(`click`, `[data-packed-dice]`, function (evt) {
				const $this = $(this);
				// Only do the fake click if the element doesn't already have its click handler.
				//  This is useful for e.g. when the other attributes get stripped before posting to chat.
				if (!$this.attr("onclick")) Renderer.dice.pRollerClickUseData(evt, this);
			})

			// region Hover replacements
			// (Based on `Renderer._renderLink_getHoverString`)
			.on(`mouseover`, `[data-plut-hover]`, function (evt) {
				const isPreload = !!evt.currentTarget.dataset.plutHoverPreload;
				const page = evt.currentTarget.dataset.plutHoverPage;
				const source = evt.currentTarget.dataset.plutHoverSource;
				let hash = evt.currentTarget.dataset.plutHoverHash;
				const preloadId = evt.currentTarget.dataset.plutHoverPreloadId;
				const hashPreEncoded = !!evt.currentTarget.dataset.plutHoverHashPreEncoded;
				let hashHover = evt.currentTarget.dataset.plutHoverHashHover;
				const hashPreEncodedHover = !!evt.currentTarget.dataset.plutHoverHashPreEncodedHover;

				if (isPreload) {
					if (preloadId == null) return;
					const preloadOptions = evt.currentTarget.dataset.plutHoverPreloadOptions;
					Renderer.hover.handlePredefinedMouseOver(evt, this, preloadId, preloadOptions ? JSON.parse(preloadOptions) : undefined);
					return
				}

				if (!page || !source || !hash) return;

				if (!hashPreEncoded) hash = UrlUtil.encodeForHash(hash);
				if (hashHover && !hashPreEncodedHover) hashHover = UrlUtil.encodeForHash(hashHover);
				if (!hashHover) hashHover = hash;

				const hoverMeta = {
					page: page,
					source: source,
					hash: hashHover,
					preloadId: preloadId,
					// Delay the appearance of the hover window if the user is pointing at a draggable element
					isDelay: !!evt.currentTarget.dataset.plutRichLink,
				};
				Renderer.hover.pHandleLinkMouseOver(evt, this, hoverMeta).then(null);
			})
			.on(`mouseleave`, `[data-plut-hover]`, function (evt) {
				Renderer.hover.handleLinkMouseLeave(evt, this);
			})
			.on(`mousemove`, `[data-plut-hover]`, function (evt) {
				Renderer.hover.handleLinkMouseMove(evt, this);
			})
			// endregion

			// region Drag-drop of `@<tag>[...]` content
			.on(`dragstart`, `[data-plut-rich-link]`, function (evt) {
				// Based on `TextEditor._onDragEntityLink`

				const entityType = evt.currentTarget.dataset.plutRichLinkEntityType;
				const page = evt.currentTarget.dataset.plutHoverPage;
				const source = evt.currentTarget.dataset.plutHoverSource;
				let hash = evt.currentTarget.dataset.plutHoverHash;
				const hashPreEncoded = !!evt.currentTarget.dataset.plutHoverHashPreEncoded;

				if (!page || !source || !hash || !entityType) return;

				if (!hashPreEncoded) hash = UrlUtil.encodeForHash(hash);

				evt.stopPropagation();
				evt.originalEvent.dataTransfer.setData(
					"text/plain",
					JSON.stringify({
						type: entityType,
						subType: UtilEvents.EVT_DATA_SUBTYPE__HOVER,
						page,
						source,
						hash,
						originalText: evt.currentTarget.dataset.plutRichLinkOriginalText,
					}),
				);
			})
			// endregion
		;
	}
}
UtilEvents.LINK_DATA_SHEET_ITEM = `data-plutonium-actor-sheet-item`;
UtilEvents.EVT_DATA_SUBTYPE__HOVER = `${SharedConsts.MODULE_NAME_FAKE}.Hover`;

export {UtilEvents};
