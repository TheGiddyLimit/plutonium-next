import {UtilActors} from "./UtilActors.js";

class UtilEvents {
	static init () {
		$(document.body)
			.on(`click`, `[${UtilEvents.LINK_DATA_SHEET_ITEM}]`, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				const $this = $(this);
				const data = JSON.parse($this.attr(UtilEvents.LINK_DATA_SHEET_ITEM));
				UtilActors.doShowSheetItem(evt, data.actorId, data.itemId);
			})
			.on(`click`, `[data-packed-dice]`, function (evt) {
				const $this = $(this);
				// Only do the fake click if the element doesn't already have its click handler.
				//  This is useful for e.g. when the other attributes get stripped before posting to chat.
				if (!$this.attr("onclick")) Renderer.dice.pRollerClickUseData(evt, this);
			})
			// region Hover replacements
			// (Based on `Renderer._renderLink_getHoverString`)
			.on(`mouseover`, `[data-plut-hover]`, function (evt) {
				const $this = $(this);
				const hoverMeta = $this.data("plut-hover");
				Renderer.hover.pHandleLinkMouseOver(evt, this, hoverMeta);
			})
			.on(`mouseleave`, `[data-plut-hover]`, function (evt) {
				Renderer.hover.handleLinkMouseLeave(evt, this);
			})
			.on(`mousemove`, `[data-plut-hover]`, function (evt) {
				Renderer.hover.handleLinkMouseMove(evt, this);
			})
			// endregion
		;
	}
}
UtilEvents.LINK_DATA_SHEET_ITEM = `data-plutonium-actor-sheet-item`;

export {UtilEvents};
