import {Config} from "./Config.js";

class UtilRenderer {
	static init () {
		Hooks.on("plutonium.configUpdate", () => this._handleConfigUpdate());
		this._handleConfigUpdate();
	}

	static _handleConfigUpdate () {
		Renderer.get().setInternalLinksDisabled(Config.get("import", "isRendererLinksDisabled"));
	}
}

export {UtilRenderer};
