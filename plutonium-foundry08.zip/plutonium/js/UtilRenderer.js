import {Config} from "./Config.js";
import {SharedConsts} from "../shared/SharedConsts.js";

class UtilRenderer {
	static init () {
		Hooks.on(`${SharedConsts.MODULE_NAME_FAKE}.configUpdate`, () => this._handleConfigUpdate());
		this._handleConfigUpdate();
	}

	static _handleConfigUpdate () {
		Renderer.get().setInternalLinksDisabled(Config.get("import", "isRendererLinksDisabled"));
	}
}

export {UtilRenderer};
