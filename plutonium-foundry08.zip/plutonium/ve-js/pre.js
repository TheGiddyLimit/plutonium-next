Object.defineProperty(window, 'IS_VTT', {
	value: true,
	writable: false
});
