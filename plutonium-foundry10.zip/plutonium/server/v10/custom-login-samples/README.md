# Custom Login Samples

With `plutonium-backend-addon-custom-login.mjs` installed, copy these files into your world folder (alongside `world.json`).
