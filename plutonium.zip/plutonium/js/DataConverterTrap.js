import {Vetools} from "./Vetools.js";

class DataConverterTrap {
	static _SIDE_LOAD_OPTS = {
		propBrew: "foundryTrap",
		fnLoadJson: Vetools.pGetTrapHazardSideData.bind(Vetools),
		propJson: "trap",
	};
}

export {DataConverterTrap};
