import {MenuTitle} from "./MenuTitle.js";

class MenuTitleItemDirectory extends MenuTitle {}
MenuTitleItemDirectory._HOOK_NAME = "renderItemDirectory";
MenuTitleItemDirectory._EVT_NAMESPACE = "plutonium-item-directory-title-menu";
MenuTitleItemDirectory._TOOL_LIST = [];

export {MenuTitleItemDirectory};
