class Patcher_ChatLog {
	static prePreInit () {
		/* No-op */
	}
}

export {Patcher_ChatLog};
