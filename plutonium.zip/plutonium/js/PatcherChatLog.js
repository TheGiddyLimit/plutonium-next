class Patcher_ChatLog {
	static preInit () {
		/* No-op */
	}
}

export {Patcher_ChatLog};
