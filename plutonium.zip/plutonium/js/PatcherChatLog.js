class Patcher_ChatLog {
	static preInit () {
		Hooks.on("getChatLogEntryContext", (html, entryOptions) => {
			entryOptions.push({
				name: "Delete Message",
				icon: "<i class=\"fas fa-trash fa-fw\"></i>",
				condition: li => {
					return game.user.isGM;
				},
				callback: li => {
					const message = game.messages.get(li.data("messageId"));
					return message.delete();
				},
			});
		});
	}
}

export {Patcher_ChatLog};
